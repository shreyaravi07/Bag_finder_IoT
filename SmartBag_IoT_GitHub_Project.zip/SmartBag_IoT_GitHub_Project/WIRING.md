# Wiring Quick Reference

| Part | ESP32 DevKit V1 |
|---|---|
| Active buzzer positive | GPIO 25 (use transistor driver if required by buzzer current) |
| Active buzzer negative | GND |
| LED anode | GPIO 26 through 220 Ω resistor |
| LED cathode | GND |
| Push button terminal 1 | GPIO 27 |
| Push button opposite side | GND |

Use `INPUT_PULLUP`; the button reads LOW when pressed. For a four-leg tactile switch,
connect GPIO27 and GND to opposite electrical sides of the switch.

All grounds must be common. Check polarity before powering the circuit.
