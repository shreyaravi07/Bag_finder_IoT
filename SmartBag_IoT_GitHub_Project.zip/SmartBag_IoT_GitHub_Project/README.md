# IoT-Enabled Smart Bag Locator and Anti-Loss Alert System Using ESP32

A short-range Bluetooth Low Energy (BLE) bag locator prototype. An Android phone uses
**nRF Connect for Mobile** to connect to the ESP32 BLE device named `SmartBag` and send
`FIND` / `LOCATE` and `STOP` commands. The ESP32 controls an audible buzzer and a status
LED. The firmware also starts a 5-second anti-loss timer after BLE disconnection.

> **Scope:** This is a short-range BLE alert system. It does not provide GPS, live location,
> cloud tracking, or internet-based tracking.

## Features

- ESP32 DevKit V1 acts as the controller and BLE peripheral.
- BLE device name: `SmartBag`.
- `FIND` or `LOCATE` command turns the active buzzer ON.
- `STOP` command turns the active buzzer OFF.
- LED indicates BLE connection state (ON while connected).
- Physical push button toggles the buzzer.
- On BLE disconnection, firmware starts a 5-second timer and activates the buzzer once
  the delay expires. Reconnection cancels the pending disconnection alert.

## Hardware

| Component | Connection |
|---|---|
| ESP32 DevKit V1 | Main controller |
| Active buzzer (+) | GPIO 25 |
| Active buzzer (-) | GND |
| LED anode (+) | GPIO 26 through 220 Ω resistor |
| LED cathode (-) | GND |
| Push button | GPIO 27 to GND (`INPUT_PULLUP`) |
| Phone | BLE connection using nRF Connect |

All circuit grounds must be common. If the buzzer draws more current than an ESP32 GPIO
can safely supply, drive it through an NPN transistor or suitable driver stage rather than
directly from the GPIO.

## Power and battery safety

For initial testing, power the ESP32 through USB. If using a 3.7 V 18650 cell, use a suitable
protected cell, a proper single-cell Li-ion charger, and a regulated supply appropriate for
the ESP32 board. Do not connect a raw 3.7 V cell directly to the ESP32 3V3 pin or assume
that a battery holder alone provides regulation/protection. Verify the regulator output and
polarity with a multimeter before connecting it. Avoid connecting USB and an external supply
at the same time unless the board's power design explicitly supports it.

## Software requirements

- Visual Studio Code
- PlatformIO extension
- PlatformIO Espressif32 platform
- Arduino framework for ESP32
- nRF Connect for Mobile (Android/iOS)

The ESP32 Arduino BLE headers used are provided by the Arduino-ESP32 framework.

## Build and upload

1. Open this folder in Visual Studio Code.
2. Install the PlatformIO extension if it is not already installed.
3. Wait for PlatformIO to initialise the project.
4. Connect the ESP32 DevKit V1 using a USB data cable.
5. Select the correct serial port in PlatformIO if required.
6. Build the project.
7. Upload the firmware.
8. Open the Serial Monitor at **115200 baud**.

The project configuration is in `platformio.ini`; firmware is in `src/main.cpp`.

## Connect using nRF Connect

1. Turn on Bluetooth on the phone.
2. Open nRF Connect and scan for nearby BLE devices.
3. Connect to **SmartBag**.
4. Expand the advertised service and open the writable characteristic.
5. Select UTF-8 / text input and write `FIND` to activate the buzzer.
6. Write `STOP` to turn the buzzer off.

### BLE identifiers

- Service UUID: `4fafc201-1fb5-459e-8fcc-c5c9c331914b`
- Characteristic UUID: `beb5483e-36e1-4688-b7f5-ea07361b26a8`

## Pin configuration

| GPIO | Function |
|---|---|
| GPIO 25 | Active buzzer |
| GPIO 26 | Status LED (220 Ω series resistor) |
| GPIO 27 | Push button to GND |

The button uses the ESP32 internal pull-up. It is active LOW.

## Project diagrams and images

Project-specific architecture, operating workflow, circuit wiring, and firmware flow diagrams
are in `docs/diagrams/`.

The `docs/hardware_implementation/` folder contains a SmartBag-specific wiring and phone-control illustration. It is an illustrative reference, not a photograph of the assembled prototype. Add genuine photos of your own physical SmartBag device before publishing if available. No radar-project photos or radar hardware are included.

## Validation checklist

- [ ] ESP32 advertises as `SmartBag`.
- [ ] Phone connects through nRF Connect.
- [ ] `FIND` activates the buzzer.
- [ ] `STOP` deactivates the buzzer.
- [ ] LED turns ON while BLE is connected and OFF after disconnection.
- [ ] Push button toggles buzzer state.
- [ ] Disconnect for more than 5 seconds and verify the anti-loss alert.
- [ ] Reconnect and verify the pending disconnect alert is cancelled.
- [ ] Confirm the final battery/regulator arrangement and enclosure fit.

The `FIND` and `STOP` BLE commands were reported as working during development. The
anti-loss disconnect timing should be tested on the final assembled unit before claiming
that behavior as fully validated.

## Repository structure

```text
SmartBag_IoT_GitHub_Project/
├── platformio.ini
├── src/
│   └── main.cpp
├── docs/
│   ├── diagrams/
│   └── hardware_implementation/
│       └── README.txt
└── README.md
```

## License

Add a license file if you intend to publish or redistribute this project under specific terms.
