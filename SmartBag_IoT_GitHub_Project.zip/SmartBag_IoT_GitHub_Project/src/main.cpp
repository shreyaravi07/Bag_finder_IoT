#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// IoT-Enabled Smart Bag Locator and Anti-Loss Alert System
// Board: ESP32 DevKit V1
// BLE device name: SmartBag

static const int BUZZER_PIN = 25;   // Active buzzer, ON = HIGH
static const int LED_PIN = 26;      // LED through 220 ohm resistor
static const int BUTTON_PIN = 27;   // Push button from GPIO27 to GND

static const unsigned long ANTI_LOSS_DELAY_MS = 5000;
static const unsigned long DEBOUNCE_MS = 50;

// BLE UUIDs used by the SmartBag project
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

BLEServer *pServer = nullptr;
BLECharacteristic *pCharacteristic = nullptr;

volatile bool deviceConnected = false;
bool buzzerOn = false;
bool previousButtonReading = HIGH;
bool stableButtonState = HIGH;
unsigned long lastDebounceTime = 0;
unsigned long disconnectedAt = 0;
bool disconnectTimerActive = false;

void setBuzzer(bool state) {
  buzzerOn = state;
  digitalWrite(BUZZER_PIN, buzzerOn ? HIGH : LOW);
  Serial.println(buzzerOn ? "BUZZER: ON" : "BUZZER: OFF");
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    deviceConnected = true;
    disconnectTimerActive = false;
    digitalWrite(LED_PIN, HIGH);
    setBuzzer(false);
    Serial.println("BLE CONNECTED");
  }

  void onDisconnect(BLEServer *server) override {
    deviceConnected = false;
    digitalWrite(LED_PIN, LOW);
    disconnectedAt = millis();
    disconnectTimerActive = true;
    Serial.println("BLE DISCONNECTED - anti-loss timer started");
    server->startAdvertising();
  }
};

class CharacteristicCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *characteristic) override {
    std::string rxValue = characteristic->getValue();
    String command = String(rxValue.c_str());
    command.trim();
    command.toUpperCase();

    Serial.print("BLE COMMAND: ");
    Serial.println(command);

    if (command == "FIND" || command == "LOCATE") {
      disconnectTimerActive = false;
      setBuzzer(true);
    } else if (command == "STOP") {
      setBuzzer(false);
    } else {
      Serial.println("Unknown command. Use FIND, LOCATE, or STOP.");
    }
  }
};

void checkButton() {
  bool reading = digitalRead(BUTTON_PIN);

  if (reading != previousButtonReading) {
    lastDebounceTime = millis();
  }

  if ((millis() - lastDebounceTime) > DEBOUNCE_MS) {
    if (reading != stableButtonState) {
      stableButtonState = reading;
      if (stableButtonState == LOW) {
        setBuzzer(!buzzerOn);
        Serial.println("Physical button pressed");
      }
    }
  }
  previousButtonReading = reading;
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  setBuzzer(false);
  digitalWrite(LED_PIN, LOW);

  BLEDevice::init("SmartBag");
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  pCharacteristic = pService->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_WRITE
  );
  pCharacteristic->setCallbacks(new CharacteristicCallbacks());
  pCharacteristic->setValue("SmartBag ready");

  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  BLEDevice::startAdvertising();

  Serial.println("================================");
  Serial.println("       SMART BAG SECURITY");
  Serial.println("================================");
  Serial.println("BLE Name : SmartBag");
  Serial.println("Status   : Waiting for phone");
  Serial.println("Commands : FIND / LOCATE / STOP");
  Serial.println("================================");
}

void loop() {
  checkButton();

  if (!deviceConnected && disconnectTimerActive) {
    if (millis() - disconnectedAt >= ANTI_LOSS_DELAY_MS) {
      setBuzzer(true);
      disconnectTimerActive = false; // alert once per disconnect event
      Serial.println("ANTI-LOSS ALERT: phone connection lost");
    }
  }

  delay(5);
}
